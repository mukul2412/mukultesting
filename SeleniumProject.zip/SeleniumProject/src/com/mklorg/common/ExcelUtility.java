/*Excel utility for full data from excel jxl*/
package com.mklorg.common;

import java.util.LinkedHashMap;
import java.util.Map;
import java.io.File;
import java.io.IOException;

import jxl.Sheet;
import jxl.Workbook;
import jxl.read.biff.BiffException;

public class ExcelUtility {

	public Map<String, LinkedHashMap<String, String>> newReadExcel(
			String excelPath) {
		Map<String, LinkedHashMap<String, String>> newTestList;
		newTestList = new LinkedHashMap<String, LinkedHashMap<String, String>>();
		try {
			/** this is the excel workbook */
			Workbook workBook = null;
			/*
			 * File fileExcel = new File("//abc//xyz.xls"); workBook =
			 * Workbook.getWorkbook(fileExcel);
			 */
			workBook = Workbook.getWorkbook(new File(excelPath));
			Sheet sheet = workBook.getSheet("Sheet1");
			int columns = sheet.getColumns();
			int rows = sheet.getRows();
			System.out.println("Rows : " + rows + "Columns : " + columns);
			if (rows > 1) {
				for (int i = 1; i < rows; i++) {
					String serialNo = sheet.getCell(0, i).getContents().trim();
					for (int j = 0; j < columns; j++) {
						if (j == 0) {
							newTestList.put(serialNo,
									new LinkedHashMap<String, String>());
						} else {
							newTestList.get(serialNo).put(
									sheet.getCell(j, 0).getContents(),
									sheet.getCell(j, i).getContents());
						}
					}
				}
			} else {
				System.out.println("No test case preset in excel ");
			}
			workBook.close();
		} catch (BiffException | IOException e) {
			System.out.println("Exception occured : " + e.getMessage());
		}
		return newTestList;

	}

	public Object[][] getMultiDataForTest(
			Map<String, LinkedHashMap<String, String>> fullsheetData,
			String testcaseName) {
		int count = 0;
		for (int i = 1; i <= fullsheetData.size(); i++) {
			if (fullsheetData.get(String.valueOf(i)).get("TestCaseName")
					.equals(testcaseName)) {
				count++;
			}
		}
		System.out
				.println("count of iteration for the current test : " + count);
		Object[][] arrayExcelData = new Map[count][1];
		int enteredDataCount = 0;
		for (int j = 1; j <= fullsheetData.size(); j++) {
			if (enteredDataCount == count) {
				break;
			}
			if (fullsheetData.get(String.valueOf(j)).get("TestCaseName")
					.equals(testcaseName)) {
				arrayExcelData[enteredDataCount][0] = fullsheetData.get(String
						.valueOf(j));
				enteredDataCount++;
			}
		}
		System.out
				.println("Count of iteration data successfully retrieved from input excel is : "
						+ enteredDataCount);
		return arrayExcelData;
		// Count of iteration
	}

}
