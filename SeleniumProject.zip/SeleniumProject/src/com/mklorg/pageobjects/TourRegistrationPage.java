package com.mklorg.pageobjects;

import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TourRegistrationPage {
	private static final long DRIVERWAITSECS = 2000;

	private WebDriver driver;

	@FindBy(name = "firstName")
	private WebElement firstName;

	@FindBy(name = "lastName")
	private WebElement lastName;

	@FindBy(name = "phone")
	private WebElement phone;

	@FindBy(id = "userName")
	private WebElement emailId;

	@FindBy(name = "address1")
	private WebElement addressLine1;

	@FindBy(name = "address2")
	private WebElement addressLine2;

	@FindBy(name = "city")
	private WebElement city;

	@FindBy(name = "state")
	private WebElement state;

	@FindBy(name = "postalCode")
	private WebElement postalCode;

	@FindBy(name = "country")
	private WebElement countryDropdown;

	@FindBy(id = "email")
	private WebElement userId;

	@FindBy(name = "password")
	private WebElement password;

	@FindBy(name = "confirmPassword")
	private WebElement confirmPassword;

	@FindBy(name = "register")
	private WebElement registerBtn;

	public WebDriver getDriver() {
		return driver;
	}

	public WebElement getFirstName() {
		return firstName;
	}

	public WebElement getLastName() {
		return lastName;
	}

	public WebElement getPhone() {
		return phone;
	}

	public WebElement getEmailId() {
		return emailId;
	}

	public WebElement getAddressLine1() {
		return addressLine1;
	}

	public WebElement getAddressLine2() {
		return addressLine2;
	}

	public WebElement getCity() {
		return city;
	}

	public WebElement getState() {
		return state;
	}

	public WebElement getCountryDropdown() {
		return countryDropdown;
	}

	public WebElement getUserId() {
		return userId;
	}

	public WebElement getPassword() {
		return password;
	}

	public WebElement getConfirmPassword() {
		return confirmPassword;
	}

	public WebElement getPostalCode() {
		return postalCode;
	}

	public TourRegistrationPage(WebDriver driverPassed) {
		this.driver = driverPassed;
		PageFactory.initElements(driver, this);
	}

	public void sleep() throws InterruptedException {
     Thread.sleep(DRIVERWAITSECS);
	}

	/*
	 * public registerUserOperation() }
	 */
	public void enterFirstName(String firstNameValue) throws InterruptedException {
		sleep();
		WebDriverWait wait = new WebDriverWait(driver, DRIVERWAITSECS);
		wait.until(ExpectedConditions.visibilityOf(getFirstName()));
		getFirstName().sendKeys(firstNameValue);
	}

	public void enterlastName(String lastNameValue) throws InterruptedException  {
		sleep();
		WebDriverWait wait = new WebDriverWait(driver, DRIVERWAITSECS);
		wait.until(ExpectedConditions.visibilityOf(getLastName()));
		getLastName().sendKeys(lastNameValue);
	}

	public void enterPhoneNum(String phoneNumValue) throws InterruptedException  {
		sleep();
		WebDriverWait wait = new WebDriverWait(driver, DRIVERWAITSECS);
		wait.until(ExpectedConditions.visibilityOf(getPhone()));
		getPhone().sendKeys(phoneNumValue);
	}

	public void enterEmailId(String emailIdValue) throws InterruptedException  {
		sleep();
		WebDriverWait wait = new WebDriverWait(driver, DRIVERWAITSECS);
		wait.until(ExpectedConditions.visibilityOf(getEmailId()));
		getEmailId().sendKeys(emailIdValue);
	}

	public void enterAddresslineOne(String AddresslineOneValue) throws InterruptedException  {
		sleep();
		WebDriverWait wait = new WebDriverWait(driver, DRIVERWAITSECS);
		wait.until(ExpectedConditions.visibilityOf(getLastName()));
		getAddressLine1().sendKeys(AddresslineOneValue);
	}

	public void enterAddresslineTwo(String AddresslineTwoValue) throws InterruptedException  {
		sleep();
		WebDriverWait wait = new WebDriverWait(driver, DRIVERWAITSECS);
		wait.until(ExpectedConditions.visibilityOf(getLastName()));
		getAddressLine2().sendKeys(AddresslineTwoValue);
	}

	public void enterCity(String cityValue) throws InterruptedException  {
		sleep();
		WebDriverWait wait = new WebDriverWait(driver, DRIVERWAITSECS);
		wait.until(ExpectedConditions.visibilityOf(getLastName()));
		getCity().sendKeys(cityValue);
	}

	public void enterState(String stateValue) throws InterruptedException  {
		sleep();
		WebDriverWait wait = new WebDriverWait(driver, DRIVERWAITSECS);
		wait.until(ExpectedConditions.visibilityOf(getState()));
		getState().sendKeys(stateValue);
	}

	public void enterPostcode(String postcodeValue) throws InterruptedException  {
		sleep();
		WebDriverWait wait = new WebDriverWait(driver, DRIVERWAITSECS);
		wait.until(ExpectedConditions.visibilityOf(getPostalCode()));
		getPostalCode().sendKeys(postcodeValue);
	}

	public void selectCountryDropdown(String countryValue) throws InterruptedException  {
		sleep();
		WebDriverWait wait = new WebDriverWait(driver, DRIVERWAITSECS);
		wait.until(ExpectedConditions.visibilityOf(getCountryDropdown()));
		Select select = new Select(getCountryDropdown());
		select.selectByVisibleText(countryValue);
	}

	public void enterUserId(String userIdValue) throws InterruptedException  {
		sleep();
		WebDriverWait wait = new WebDriverWait(driver, DRIVERWAITSECS);
		wait.until(ExpectedConditions.visibilityOf(getUserId()));
		getUserId().sendKeys(userIdValue);
	}

	public void enterPassword(String UserIdValue) throws InterruptedException  {
		sleep();
		WebDriverWait wait = new WebDriverWait(driver, DRIVERWAITSECS);
		wait.until(ExpectedConditions.visibilityOf(getPassword()));
		getPassword().sendKeys(UserIdValue);
	}

	public void enterConfirmPassword(String UserIdValue) throws InterruptedException  {
		sleep();
		WebDriverWait wait = new WebDriverWait(driver, DRIVERWAITSECS);
		wait.until(ExpectedConditions.visibilityOf(getConfirmPassword()));
		getConfirmPassword().sendKeys(UserIdValue);
	}

	public void registrationOperation(Map<String, String> localMultiData) throws InterruptedException  {
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);

		enterFirstName(localMultiData.get("firstname"));
		enterlastName(localMultiData.get("lastname"));
		enterPhoneNum(localMultiData.get("phoneNum"));
		enterEmailId(localMultiData.get("email"));
		enterAddresslineOne(localMultiData.get("addressLine1"));
		enterAddresslineTwo(localMultiData.get("addressLine2"));
		enterCity(localMultiData.get("city"));
		enterState(localMultiData.get("state"));
		enterPostcode(localMultiData.get("postcode"));
		selectCountryDropdown(localMultiData.get("country"));
		enterUserId(localMultiData.get("userid"));
		enterPassword(localMultiData.get("password"));
		enterConfirmPassword(localMultiData.get("password"));
		registerBtn.click();

	}

	public void testRegister() throws InterruptedException {

		enterFirstName("firstname");
	}
}