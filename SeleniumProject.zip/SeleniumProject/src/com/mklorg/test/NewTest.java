package com.mklorg.test;

import java.util.Map;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.mklorg.common.ExcelUtility;
import com.mklorg.pageobjects.TourRegistrationPage;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Test;

import com.mklorg.pageobjects.TourRegistrationPage;

public class NewTest {
  @Test
  public void f() throws InterruptedException {
	  WebDriver driver;
		
		/*System.setProperty("webdriver.ie.driver",
				System.getProperty("user.dir") + "/src/com/mklorg/test/resource/IEDriverServer.exe");
		
		driver = new InternetExplorerDriver();*/
	  driver = new FirefoxDriver();
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.get("http://newtours.demoaut.com/mercuryregister.php");
		String currentWindow = driver.getWindowHandle();
		driver.switchTo().window(currentWindow);
		Thread.sleep(10000);
		System.out.println(driver.getTitle());
		TourRegistrationPage objTourRegistrationPage = new TourRegistrationPage(driver);
		Thread.sleep(3000);
		objTourRegistrationPage.testRegister();
		Thread.sleep(5000);
	  
  }
}
