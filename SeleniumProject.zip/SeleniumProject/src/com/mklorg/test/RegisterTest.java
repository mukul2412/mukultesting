package com.mklorg.test;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.mklorg.common.ExcelUtility;
import com.mklorg.pageobjects.TourRegistrationPage;

public class RegisterTest {

	TourRegistrationPage objTourRegistrationPage;
	public Map<String, LinkedHashMap<String, String>> fullExcelData;

	@DataProvider(name = "dataForTest")
	public Object[][] aaTestData() {
		ExcelUtility ObjectExcelUtility = new ExcelUtility();

		String excelPath = System.getProperty("user.dir")
				+ "/src/com/mklorg/test/resource/TestData.xls";
		fullExcelData = ObjectExcelUtility.newReadExcel(excelPath);
		System.out.println("Total count of test case : "
				+ String.valueOf(fullExcelData.size()));
		Object[][] arrayobject = ObjectExcelUtility.getMultiDataForTest(
				fullExcelData, "RegisterTest");
		return arrayobject;
	}

	@Test(dataProvider = "dataForTest")
	public void registerTest(Map<String, String> multiDataHere)
			throws InterruptedException {
		WebDriver driver;
		Map<String, String> localMultiData = multiDataHere;
		/*
		 * For IE run System.setProperty("webdriver.ie.driver",
		 * System.getProperty("user.dir") +
		 * "/src/com/mklorg/test/resource/IEDriverServer.exe"); driver = new
		 * InternetExplorerDriver();
		 */
		driver = new FirefoxDriver();
		driver.manage().window().maximize();
		Thread.sleep(5000);
		driver.get(localMultiData.get("url"));
		driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		System.out.println(driver.getTitle());
		objTourRegistrationPage = new TourRegistrationPage(driver);
		objTourRegistrationPage.registrationOperation(localMultiData);
		Thread.sleep(5000);
		driver.close();
	}

}
